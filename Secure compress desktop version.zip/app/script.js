(function(){
  if (window.pdfjsLib) {
    pdfjsLib.GlobalWorkerOptions.workerSrc = 'libs/pdf.worker.min.js';
  }

  var root = document.documentElement;
  var themeToggle = document.getElementById('themeToggle');
  function applyTheme(theme){
    root.setAttribute('data-theme', theme);
    if(!themeToggle) return;
    themeToggle.setAttribute('aria-pressed', theme === 'dark' ? 'true' : 'false');
    themeToggle.setAttribute('aria-label', theme === 'dark' ? 'Switch to light mode' : 'Switch to dark mode');
  }
  applyTheme(root.getAttribute('data-theme') || 'light');
  if(themeToggle){
    themeToggle.addEventListener('click', function(){
      applyTheme(root.getAttribute('data-theme') === 'dark' ? 'light' : 'dark');
    });
  }

  var MAX_FILE_BYTES = 200 * 1024 * 1024; // 200MB

  var TOOL_CONFIG = {
    compress: { accept: '.pdf', exts: ['pdf'], hint: 'PDF files up to 200MB', actionLabel: 'Compress file', processingLabel: 'Compressing…', tabLabel: 'Compress PDF',
      note: 'High-strength compression: pages are re-encoded as sharp images at a reduced size. Great for shrinking large or scanned PDFs. ' },
    w2p:      { accept: '.doc,.docx', exts: ['doc','docx'], hint: 'Word documents up to 200MB', actionLabel: 'Convert to PDF', processingLabel: 'Converting to PDF…', tabLabel: 'Word to PDF', note: '' },
    p2w:      { accept: '.pdf', exts: ['pdf'], hint: 'PDF files up to 200MB', actionLabel: 'Convert to Word', processingLabel: 'Converting to Word…', tabLabel: 'PDF to Word',
      note: 'Pages with a real text layer convert directly. For a scanned document, turn on OCR below so the result stays editable instead of being a picture.' }
  };

  var state = { tool: 'compress', file: null };

  var els = {
    tabs: document.querySelectorAll('.tab'),
    dropzone: document.getElementById('dropzone'),
    dzHint: document.getElementById('dzHint'),
    dzError: document.getElementById('dzError'),
    toolNote: document.getElementById('toolNote'),
    ocrToggle: document.getElementById('ocrToggle'),
    ocrCheckbox: document.getElementById('ocrCheckbox'),
    fileInput: document.getElementById('fileInput'),
    fileInfo: document.getElementById('fileInfo'),
    fiName: document.getElementById('fiName'),
    fiSize: document.getElementById('fiSize'),
    fiRemove: document.getElementById('fiRemove'),
    actionBtn: document.getElementById('actionBtn'),
    progressWrap: document.getElementById('progressWrap'),
    progressLabel: document.getElementById('progressLabel'),
    result: document.getElementById('result'),
    resultTitle: document.getElementById('resultTitle'),
    resultDetail: document.getElementById('resultDetail'),
    resultDownload: document.getElementById('resultDownload')
  };

  function humanSize(bytes){
    if(bytes < 1024) return bytes + ' B';
    if(bytes < 1024*1024) return (bytes/1024).toFixed(1) + ' KB';
    return (bytes/(1024*1024)).toFixed(2) + ' MB';
  }

  function extOf(name){
    var m = /\.([a-zA-Z0-9]+)$/.exec(name);
    return m ? m[1].toLowerCase() : '';
  }

  function resetPanel(){
    state.file = null;
    els.fileInfo.hidden = true;
    els.dropzone.hidden = false;
    els.dzError.style.display = 'none';
    els.actionBtn.disabled = true;
    els.progressWrap.style.display = 'none';
    els.result.style.display = 'none';
    els.result.classList.remove('ok','err');
    els.fileInput.value = '';
  }

  function selectTool(tool){
    state.tool = tool;
    els.tabs.forEach(function(t){
      var active = t.dataset.tool === tool;
      t.classList.toggle('active', active);
      t.setAttribute('aria-selected', active ? 'true' : 'false');
    });
    var cfg = TOOL_CONFIG[tool];
    els.fileInput.setAttribute('accept', cfg.accept);
    els.dzHint.textContent = cfg.hint;
    els.actionBtn.textContent = cfg.actionLabel;
    if(els.toolNote){
      els.toolNote.textContent = cfg.note || '';
      els.toolNote.style.display = cfg.note ? 'block' : 'none';
    }
    if(els.ocrToggle){
      els.ocrToggle.hidden = tool !== 'p2w';
      els.ocrToggle.style.display = tool === 'p2w' ? 'block' : 'none';
    }
    if(els.ocrCheckbox) els.ocrCheckbox.checked = false;
    resetPanel();
  }

  els.tabs.forEach(function(tab){
    tab.addEventListener('click', function(){ selectTool(tab.dataset.tool); });
  });

  els.dropzone.addEventListener('click', function(){ els.fileInput.click(); });
  els.dropzone.addEventListener('keydown', function(e){
    if(e.key === 'Enter' || e.key === ' '){ e.preventDefault(); els.fileInput.click(); }
  });
  ['dragover','dragenter'].forEach(function(evt){
    els.dropzone.addEventListener(evt, function(e){ e.preventDefault(); els.dropzone.classList.add('dragover'); });
  });
  ['dragleave','dragend'].forEach(function(evt){
    els.dropzone.addEventListener(evt, function(e){ els.dropzone.classList.remove('dragover'); });
  });
  els.dropzone.addEventListener('drop', function(e){
    e.preventDefault();
    els.dropzone.classList.remove('dragover');
    if(e.dataTransfer.files && e.dataTransfer.files[0]) handleFile(e.dataTransfer.files[0]);
  });
  els.fileInput.addEventListener('change', function(e){
    if(e.target.files && e.target.files[0]) handleFile(e.target.files[0]);
  });

  function handleFile(file){
    var cfg = TOOL_CONFIG[state.tool];
    var ext = extOf(file.name);
    if(cfg.exts.indexOf(ext) === -1){
      els.dzError.textContent = 'That file type doesn\'t match this tool. Expected: ' + cfg.hint.toLowerCase() + '.';
      els.dzError.style.display = 'block';
      return;
    }
    if(file.size > MAX_FILE_BYTES){
      els.dzError.textContent = 'This file is larger than 200MB. Try a smaller file.';
      els.dzError.style.display = 'block';
      return;
    }
    els.dzError.style.display = 'none';
    state.file = file;
    els.fiName.textContent = file.name;
    els.fiSize.textContent = humanSize(file.size);
    els.fileInfo.hidden = false;
    els.dropzone.hidden = true;
    els.actionBtn.disabled = false;
    els.result.style.display = 'none';
  }

  els.fiRemove.addEventListener('click', function(e){
    e.preventDefault();
    e.stopPropagation();
    resetPanel();
  });

  function escapeHtml(s){
    return s.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
  }

  function dataUrlToBytes(dataUrl){
    var base64 = dataUrl.split(',')[1];
    var binary = atob(base64);
    var bytes = new Uint8Array(binary.length);
    for (var i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
    return bytes;
  }

  async function renderPdfAtQuality(srcPdf, numPages, dpi, quality, onPage){
    var outDoc = await PDFLib.PDFDocument.create();
    for (var p = 1; p <= numPages; p++){
      var page = await srcPdf.getPage(p);
      var basePoints = page.getViewport({ scale: 1 });
      var renderViewport = page.getViewport({ scale: dpi / 72 });
      var canvas = document.createElement('canvas');
      canvas.width = Math.max(1, Math.ceil(renderViewport.width));
      canvas.height = Math.max(1, Math.ceil(renderViewport.height));
      var ctx = canvas.getContext('2d');
      await page.render({ canvasContext: ctx, viewport: renderViewport }).promise;
      var jpegBytes = dataUrlToBytes(canvas.toDataURL('image/jpeg', quality));
      var img = await outDoc.embedJpg(jpegBytes);
      var pdfPage = outDoc.addPage([basePoints.width, basePoints.height]);
      pdfPage.drawImage(img, { x: 0, y: 0, width: basePoints.width, height: basePoints.height });
      canvas.width = 0; canvas.height = 0;
      if(onPage) onPage(p, numPages);
    }
    return outDoc.save({ useObjectStreams: true });
  }

  // Compresses by re-encoding each page as a JPEG at reduced resolution/quality.
  // Tries progressively stronger settings until the result is at least 50% smaller
  // than the original, or until the settings run out (in which case the smallest
  // result found is used, and the real percentage achieved is reported honestly).
  async function compressPdf(file, onProgress){
    if(!window.PDFLib || !window.pdfjsLib) throw new Error('engine-missing');
    var buf = await file.arrayBuffer();
    var srcPdf = await pdfjsLib.getDocument({ data: buf }).promise;
    var numPages = srcPdf.numPages;
    var originalSize = file.size;
    var targetSize = originalSize * 0.5;

    var passes = [
      { dpi: 120, quality: 0.55 },
      { dpi: 100, quality: 0.4 },
      { dpi: 85,  quality: 0.3 }
    ];

    var best = null;
    for (var i = 0; i < passes.length; i++){
      var pass = passes[i];
      var bytes = await renderPdfAtQuality(srcPdf, numPages, pass.dpi, pass.quality, function(p, total){
        if(onProgress) onProgress('Compressing page ' + p + ' of ' + total + '…');
      });
      if(!best || bytes.length < best.length) best = bytes;
      if(best.length <= targetSize) break;
    }
    return best;
  }

  var DOC_RENDER_CSS =
    '.doc-render{ font-family:Calibri,"Segoe UI",Arial,sans-serif; font-size:15px; line-height:1.5; color:#1a1a1a; }' +
    '.doc-render h1, .doc-render h2, .doc-render h3{ font-family:inherit; color:#111111; }' +
    '.doc-render p{ margin:0 0 10px; }' +
    '.doc-render h1{ font-size:1.9em; margin:0 0 14px; font-weight:700; line-height:1.25; }' +
    '.doc-render h2{ font-size:1.5em; margin:18px 0 10px; font-weight:700; line-height:1.25; }' +
    '.doc-render h3{ font-size:1.2em; margin:16px 0 8px; font-weight:700; line-height:1.3; }' +
    '.doc-render ul, .doc-render ol{ margin:0 0 10px; padding-left:28px; }' +
    '.doc-render li{ margin-bottom:4px; }' +
    '.doc-render table{ border-collapse:collapse; width:100%; margin:0 0 14px; }' +
    '.doc-render td, .doc-render th{ border:1px solid #999; padding:6px 8px; font-size:0.95em; text-align:left; }' +
    '.doc-render img{ max-width:100%; height:auto; }' +
    '.doc-render strong{ font-weight:700; } .doc-render em{ font-style:italic; }';

  function ensureDocRenderStyle(){
    if(document.getElementById('docRenderStyle')) return;
    var styleEl = document.createElement('style');
    styleEl.id = 'docRenderStyle';
    styleEl.textContent = DOC_RENDER_CSS;
    document.head.appendChild(styleEl);
  }

  // Converts a Word document to PDF by laying it out across real, page-sized
  // containers (so a page break only ever falls between paragraphs/headings/
  // list items/tables) and rendering each page separately — rather than
  // slicing one long screenshot at a fixed pixel height, which cuts straight
  // through lines of text.
  async function wordToPdf(file, onProgress){
    if(!window.mammoth || !window.html2canvas || !window.jspdf) throw new Error('engine-missing');
    ensureDocRenderStyle();

    var buf = await file.arrayBuffer();
    var converted = await mammoth.convertToHtml({ arrayBuffer: buf }, {
      styleMap: ["p[style-name='Title'] => h1:fresh", "p[style-name='Subtitle'] => h3:fresh"]
    });

    var PAGE_W = 794;   // ~A4 width at 96dpi
    var PAGE_H = 1123;  // ~A4 height at 96dpi
    var MARGIN = 72;    // ~0.75in
    var contentW = PAGE_W - MARGIN * 2;
    var contentH = PAGE_H - MARGIN * 2;

    if(onProgress) onProgress('Laying out pages…');
    var measure = document.createElement('div');
    measure.className = 'doc-render';
    measure.style.cssText = 'position:fixed; left:-9999px; top:0; width:' + contentW + 'px;';
    measure.innerHTML = converted.value || '<p></p>';
    document.body.appendChild(measure);

    var nodes = Array.prototype.slice.call(measure.children);
    if(nodes.length === 0){
      var fallback = document.createElement('p');
      fallback.textContent = ' ';
      measure.appendChild(fallback);
      nodes = [fallback];
    }

    var pageGroups = [];
    var current = [];
    var currentHeight = 0;
    nodes.forEach(function(node){
      var h = node.offsetHeight;
      if(current.length && currentHeight + h > contentH){
        pageGroups.push(current);
        current = [];
        currentHeight = 0;
      }
      current.push(node);
      currentHeight += h;
    });
    if(current.length) pageGroups.push(current);
    if(pageGroups.length === 0) pageGroups.push([]);

    document.body.removeChild(measure);

    var jsPDF = window.jspdf.jsPDF;
    var pdf = new jsPDF({ unit: 'px', format: [PAGE_W, PAGE_H], compress: true });

    for(var p = 0; p < pageGroups.length; p++){
      if(onProgress) onProgress('Rendering page ' + (p + 1) + ' of ' + pageGroups.length + '…');
      var pageDiv = document.createElement('div');
      pageDiv.className = 'doc-render';
      pageDiv.style.cssText = 'position:fixed; left:-9999px; top:0; width:' + PAGE_W + 'px; height:' + PAGE_H + 'px; box-sizing:border-box; padding:' + MARGIN + 'px; background:#ffffff;';
      pageGroups[p].forEach(function(node){ pageDiv.appendChild(node.cloneNode(true)); });
      document.body.appendChild(pageDiv);
      var canvas = await html2canvas(pageDiv, { scale: 2, backgroundColor: '#ffffff', width: PAGE_W, height: PAGE_H });
      document.body.removeChild(pageDiv);
      var imgData = canvas.toDataURL('image/jpeg', 0.93);
      if(p > 0) pdf.addPage([PAGE_W, PAGE_H]);
      pdf.addImage(imgData, 'JPEG', 0, 0, PAGE_W, PAGE_H);
      canvas.width = 0; canvas.height = 0;
    }

    return pdf.output('arraybuffer');
  }

  // Reconstructs paragraph structure from a PDF page's text items, which pdf.js
  // returns as an unordered bag of text runs with x/y position data — it does
  // NOT return paragraphs or line breaks directly. We cluster runs into lines
  // by matching y-position, sort lines top-to-bottom, then split into
  // paragraphs wherever the vertical gap between lines is clearly bigger than
  // normal line spacing on that page. Lines whose font size is notably larger
  // than the page's typical text are treated as headings.
  function reconstructParagraphs(content){
    var items = content.items.filter(function(it){ return it.str !== undefined; });
    if(!items.length) return [];

    var lines = [];
    var tol = 2.5;
    items.forEach(function(it){
      var y = it.transform[5];
      var x = it.transform[4];
      var size = Math.hypot(it.transform[2], it.transform[3]) || 10;
      var line = null;
      for(var i = 0; i < lines.length; i++){
        if(Math.abs(lines[i].y - y) < tol){ line = lines[i]; break; }
      }
      if(!line){
        line = { y: y, parts: [], maxSize: size };
        lines.push(line);
      }
      line.maxSize = Math.max(line.maxSize, size);
      line.parts.push({ x: x, str: it.str });
    });

    lines.sort(function(a, b){ return b.y - a.y; });
    lines.forEach(function(l){
      l.parts.sort(function(a, b){ return a.x - b.x; });
      l.text = l.parts.map(function(p){ return p.str; }).join(' ').replace(/\s+/g, ' ').trim();
    });
    lines = lines.filter(function(l){ return l.text.length > 0; });
    if(!lines.length) return [];

    // Use the MODE of line-to-line gaps as the page's "normal" single-line
    // spacing, not the median — a page mixing body text with headings has
    // a few large gaps that can otherwise skew a median past genuine
    // paragraph breaks.
    var gapCounts = {};
    for(var i = 1; i < lines.length; i++){
      var g = Math.round((lines[i-1].y - lines[i].y) * 2) / 2;
      gapCounts[g] = (gapCounts[g] || 0) + 1;
    }
    var normalGap = 14, bestCount = 0;
    for(var g in gapCounts){
      if(gapCounts[g] > bestCount){ bestCount = gapCounts[g]; normalGap = parseFloat(g); }
    }
    if(!(normalGap > 0)) normalGap = 14;
    var paraGapThreshold = Math.max(normalGap * 1.35, normalGap + 4);

    var sizes = lines.map(function(l){ return l.maxSize; }).sort(function(a,b){ return a-b; });
    var medianSize = sizes[Math.floor(sizes.length / 2)] || 10;

    var blocks = [];
    var current = [];
    for(var i = 0; i < lines.length; i++){
      var isHeading = lines[i].maxSize > medianSize * 1.25 && lines[i].text.length < 90;
      var gapBefore = i > 0 ? (lines[i-1].y - lines[i].y) : 0;
      if(isHeading || (i > 0 && gapBefore > paraGapThreshold)){
        if(current.length){ blocks.push({ type: 'p', text: current.join(' ') }); current = []; }
      }
      if(isHeading){
        blocks.push({ type: 'h2', text: lines[i].text });
      } else {
        current.push(lines[i].text);
      }
    }
    if(current.length) blocks.push({ type: 'p', text: current.join(' ') });
    return blocks;
  }

  // Renders a PDF page at a higher resolution than normal viewing needs, then
  // converts it to grayscale and binarizes it with Otsu's method (an
  // automatic black/white threshold). Tesseract reads clean black-on-white
  // scans dramatically better than raw, low-contrast, color-noisy scans —
  // this preprocessing step is usually the single biggest accuracy lever for
  // OCR, more so than the recognition engine itself.
  async function preprocessedCanvasForOcr(page){
    var viewport = page.getViewport({ scale: 280/72 });
    var canvas = document.createElement('canvas');
    canvas.width = Math.max(1, Math.ceil(viewport.width));
    canvas.height = Math.max(1, Math.ceil(viewport.height));
    var ctx = canvas.getContext('2d');
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    await page.render({ canvasContext: ctx, viewport: viewport }).promise;

    var imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
    var d = imageData.data;
    var hist = new Array(256).fill(0);
    var gray = new Uint8ClampedArray(d.length / 4);
    for(var i = 0, j = 0; i < d.length; i += 4, j++){
      var g = (0.299 * d[i] + 0.587 * d[i+1] + 0.114 * d[i+2]) | 0;
      gray[j] = g;
      hist[g]++;
    }
    var total = gray.length;
    var sum = 0;
    for(var t = 0; t < 256; t++) sum += t * hist[t];
    var sumB = 0, wB = 0, maxVar = 0, threshold = 140;
    for(var t = 0; t < 256; t++){
      wB += hist[t];
      if(wB === 0) continue;
      var wF = total - wB;
      if(wF === 0) break;
      sumB += t * hist[t];
      var mB = sumB / wB, mF = (sum - sumB) / wF;
      var varBetween = wB * wF * (mB - mF) * (mB - mF);
      if(varBetween > maxVar){ maxVar = varBetween; threshold = t; }
    }
    for(var i = 0, j = 0; i < d.length; i += 4, j++){
      var v = gray[j] > threshold ? 255 : 0;
      d[i] = d[i+1] = d[i+2] = v;
    }
    ctx.putImageData(imageData, 0, 0);
    return canvas;
  }

  async function pdfToWord(file, useOcr, onProgress){
    if(!window.pdfjsLib) throw new Error('engine-missing');
    if(useOcr && !window.Tesseract) throw new Error('ocr-engine-missing');

    var buf = await file.arrayBuffer();
    var pdf = await pdfjsLib.getDocument({ data: buf }).promise;
    var numPages = pdf.numPages;

    var ocrWorker = null;
    if(useOcr){
      if(onProgress) onProgress('Loading OCR model…');
      ocrWorker = await Tesseract.createWorker('eng', 1, {
        // The OCR worker runs in its own context, so it needs absolute URLs.
        workerPath: new URL('libs/tesseract/worker.min.js', document.baseURI).href,
        corePath: new URL('libs/tesseract/core', document.baseURI).href,
        langPath: new URL('libs/tesseract/lang', document.baseURI).href,
        logger: function(m){
          if(!onProgress || !m || !m.status) return;
          var pct = (typeof m.progress === 'number') ? ' ' + Math.round(m.progress * 100) + '%' : '';
          onProgress(m.status + pct);
        }
      });
    }

    var paragraphs = [];
    try{
      for(var i=1;i<=numPages;i++){
        if(onProgress) onProgress('Reading page ' + i + ' of ' + numPages + '…');
        var page = await pdf.getPage(i);
        var content = await page.getTextContent();
        var blocks = reconstructParagraphs(content);
        var hasRealText = blocks.some(function(b){ return b.text.trim().length >= 8; });

        // A page with little to no extractable text is almost certainly a
        // scanned image rather than real text — OCR it if that's turned on.
        if(useOcr && !hasRealText){
          var canvas = await preprocessedCanvasForOcr(page);
          if(onProgress) onProgress('Running OCR on page ' + i + ' of ' + numPages + '…');
          var ocrResult = await ocrWorker.recognize(canvas);
          var ocrText = (ocrResult && ocrResult.data && ocrResult.data.text) ? ocrResult.data.text.trim() : '';
          canvas.width = 0; canvas.height = 0;
          blocks = ocrText.split(/\n\s*\n+/).map(function(s){ return s.trim(); }).filter(function(s){ return s.length; })
            .map(function(s){ return { type: 'p', text: s.replace(/\s*\n\s*/g, ' ') }; });
        }

        if(blocks.length === 0) blocks = [{ type: 'p', text: ' ' }];
        paragraphs.push(blocks.map(function(b){ return '<' + b.type + '>' + escapeHtml(b.text) + '</' + b.type + '>'; }).join('\n'));
      }
    } finally {
      if(ocrWorker) await ocrWorker.terminate();
    }

    var body = paragraphs.join('\n');
    return '<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:w="urn:schemas-microsoft-com:office:word" xmlns="http://www.w3.org/TR/REC-html40">' +
      '<head><meta charset="utf-8"><title>Document</title></head>' +
      '<body style="font-family:Calibri, Arial, sans-serif; font-size:12pt;">' + body + '</body></html>';
  }

  function sizeCompareText(originalSize, newSize){
    if(newSize >= originalSize){
      return 'This file was already well optimized, so the size stayed about the same (' + humanSize(originalSize) + ').';
    }
    var pct = Math.round((1 - newSize/originalSize) * 100);
    return humanSize(originalSize) + ' \u2192 ' + humanSize(newSize) + ' (' + pct + '% smaller).';
  }

  function showBusy(isBusy, label){
    els.actionBtn.disabled = isBusy || !state.file;
    els.fiRemove.disabled = isBusy;
    els.progressLabel.textContent = label || 'Working…';
    els.progressWrap.style.display = isBusy ? 'block' : 'none';
  }

  function showResult(ok, title, detail, blob, filename){
    els.result.style.display = 'block';
    els.result.classList.toggle('ok', ok);
    els.result.classList.toggle('err', !ok);
    els.resultTitle.textContent = title;
    els.resultDetail.textContent = detail;
    if(ok && blob){
      var url = URL.createObjectURL(blob);
      els.resultDownload.href = url;
      els.resultDownload.download = filename;
      els.resultDownload.style.display = 'inline-flex';
    } else {
      els.resultDownload.style.display = 'none';
    }
  }

  els.actionBtn.addEventListener('click', async function(){
    if(!state.file) return;
    var cfg = TOOL_CONFIG[state.tool];
    var original = state.file;
    els.result.style.display = 'none';
    showBusy(true, cfg.processingLabel);
    try{
      if(state.tool === 'compress'){
        var bytes = await compressPdf(original, function(label){ els.progressLabel.textContent = label; });
        var blob = new Blob([bytes], { type: 'application/pdf' });
        showResult(true, 'Compressed successfully', sizeCompareText(original.size, blob.size), blob, 'compressed-' + original.name);
      } else if(state.tool === 'w2p'){
        var pdfBuf = await wordToPdf(original, function(label){ els.progressLabel.textContent = label; });
        var pblob = new Blob([pdfBuf], { type: 'application/pdf' });
        var outName = original.name.replace(/\.(docx|doc)$/i, '') + '.pdf';
        showResult(true, 'Converted to PDF', 'Your document is ready to download.', pblob, outName);
      } else if(state.tool === 'p2w'){
        var useOcr = !!(els.ocrCheckbox && els.ocrCheckbox.checked);
        var html = await pdfToWord(original, useOcr, function(label){ els.progressLabel.textContent = label; });
        var wblob = new Blob([html], { type: 'application/msword' });
        var wOutName = original.name.replace(/\.pdf$/i, '') + '.doc';
        var detail = useOcr
          ? 'Scanned pages were recognized with OCR, so the text can be edited — always double-check accuracy, especially for unusual fonts or handwriting.'
          : 'Opens in Microsoft Word and most word processors.';
        showResult(true, 'Converted to Word', detail, wblob, wOutName);
      }
    } catch(err){
      console.error(err);
      var msg = (err && err.message === 'engine-missing')
        ? 'This tool\'s engine couldn\'t load. Try restarting the app, or reinstall it if the problem continues.'
        : (err && err.message === 'ocr-engine-missing')
        ? 'The OCR engine couldn\'t load. Try restarting the app, or turn OCR off to convert without it.'
        : 'We couldn\'t process this file. Make sure it\'s a valid, unlocked file and try again.';
      showResult(false, 'Something went wrong', msg, null, '');
    } finally {
      showBusy(false);
    }
  });

  selectTool(state.tool);
})();
